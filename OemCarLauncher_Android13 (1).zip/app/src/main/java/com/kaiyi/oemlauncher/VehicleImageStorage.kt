package com.kaiyi.oemlauncher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import java.io.FileOutputStream

enum class VehicleViewSide(val fileName: String, val displayLabel: String) {
    FRONT("vehicle_front_custom.png", "Foto frontal"),
    PROFILE("vehicle_profile_custom.png", "Foto lateral (perfil)"),
    BRAND_LOGO("brand_logo_custom.png", "Logotipo de bienvenida")
}

/**
 * Almacena permanentemente en filesDir las imágenes elegidas desde la galería,
 * reescalándolas de forma segura para evitar OutOfMemoryError en radios con 2 GB de RAM.
 */
class VehicleImageStorage(private val context: Context) {

    fun hasCustomImage(side: VehicleViewSide): Boolean {
        val file = getTargetFile(side)
        return file.exists() && file.length() > 0L
    }

    fun loadCustomBitmap(side: VehicleViewSide): Bitmap? {
        val file = getTargetFile(side)
        if (!file.exists()) return null
        return runCatching {
            BitmapFactory.decodeFile(file.absolutePath)
        }.getOrNull()
    }

    fun saveImageFromUri(side: VehicleViewSide, uri: Uri): Boolean {
        val resolver = context.contentResolver

        // 1. Leer solo dimensiones para calcular inSampleSize sin cargar imagen completa en RAM
        val boundsOpts = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
        }
        resolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, boundsOpts)
        } ?: return false

        if (boundsOpts.outWidth <= 0 || boundsOpts.outHeight <= 0) return false

        // 2. Decodificar con muestreo óptimo (~960x540 máx)
        val sampleSize = calculateInSampleSize(
            boundsOpts.outWidth,
            boundsOpts.outHeight,
            MAX_TARGET_WIDTH,
            MAX_TARGET_HEIGHT
        )

        val decodeOpts = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }

        val decoded = resolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, decodeOpts)
        } ?: return false

        // 3. Ajustar tamaño exacto manteniendo proporción si aún supera el límite
        val scaled = scaleDownIfNeeded(decoded, MAX_TARGET_WIDTH, MAX_TARGET_HEIGHT)
        if (scaled !== decoded) {
            decoded.recycle()
        }

        // 4. Guardar permanentemente en memoria interna privada (PNG conserva transparencia)
        val outFile = getTargetFile(side)
        return try {
            FileOutputStream(outFile).use { fos ->
                scaled.compress(Bitmap.CompressFormat.PNG, 92, fos)
            }
            true
        } catch (_: Exception) {
            false
        } finally {
            scaled.recycle()
        }
    }

    fun clearCustomImages() {
        VehicleViewSide.values().forEach { side ->
            val file = getTargetFile(side)
            if (file.exists()) {
                file.delete()
            }
        }
    }

    private fun getTargetFile(side: VehicleViewSide): File {
        return File(context.filesDir, side.fileName)
    }

    private fun calculateInSampleSize(
        width: Int,
        height: Int,
        reqWidth: Int,
        reqHeight: Int
    ): Int {
        var inSampleSize = 1
        if (height > reqHeight || width > reqWidth) {
            val halfHeight = height / 2
            val halfWidth = width / 2
            while ((halfHeight / inSampleSize) >= reqHeight &&
                (halfWidth / inSampleSize) >= reqWidth
            ) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }

    private fun scaleDownIfNeeded(bitmap: Bitmap, maxWidth: Int, maxHeight: Int): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        if (width <= maxWidth && height <= maxHeight) return bitmap

        val ratio = minOf(
            maxWidth.toFloat() / width.toFloat(),
            maxHeight.toFloat() / height.toFloat()
        )
        val targetW = (width * ratio).toInt().coerceAtLeast(1)
        val targetH = (height * ratio).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
    }

    companion object {
        private const val MAX_TARGET_WIDTH = 960
        private const val MAX_TARGET_HEIGHT = 540
    }
}
