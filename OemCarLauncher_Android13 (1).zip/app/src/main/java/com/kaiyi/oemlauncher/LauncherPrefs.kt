package com.kaiyi.oemlauncher

import android.content.Context
import android.content.SharedPreferences

class LauncherPrefs(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getAssignedPackage(slot: LauncherSlot): String? {
        return prefs.getString(slot.prefKey, null)
    }

    fun setAssignedPackage(slot: LauncherSlot, packageName: String) {
        prefs.edit().putString(slot.prefKey, packageName).apply()
    }

    fun clearAssignedPackage(slot: LauncherSlot) {
        prefs.edit().remove(slot.prefKey).apply()
    }

    fun isVehicleProfileView(): Boolean {
        return prefs.getBoolean(KEY_VEHICLE_PROFILE, false)
    }

    fun setVehicleProfileView(isProfile: Boolean) {
        prefs.edit().putBoolean(KEY_VEHICLE_PROFILE, isProfile).apply()
    }

    fun setCustomVehiclePhotoSaved(side: VehicleViewSide, saved: Boolean) {
        val key = keyForSide(side)
        prefs.edit().putBoolean(key, saved).apply()
    }

    fun hasCustomVehiclePhotoFlag(side: VehicleViewSide): Boolean {
        return prefs.getBoolean(keyForSide(side), false)
    }

    private fun keyForSide(side: VehicleViewSide): String {
        return when (side) {
            VehicleViewSide.FRONT -> KEY_CUSTOM_VEHICLE_FRONT
            VehicleViewSide.PROFILE -> KEY_CUSTOM_VEHICLE_PROFILE
            VehicleViewSide.BRAND_LOGO -> KEY_CUSTOM_BRAND_LOGO
        }
    }

    companion object {
        private const val PREFS_NAME = "oem_car_launcher_prefs"
        private const val KEY_VEHICLE_PROFILE = "vehicle_view_profile"
        private const val KEY_CUSTOM_VEHICLE_FRONT = "custom_vehicle_front"
        private const val KEY_CUSTOM_VEHICLE_PROFILE = "custom_vehicle_profile"
        private const val KEY_CUSTOM_BRAND_LOGO = "custom_brand_logo"
    }
}
