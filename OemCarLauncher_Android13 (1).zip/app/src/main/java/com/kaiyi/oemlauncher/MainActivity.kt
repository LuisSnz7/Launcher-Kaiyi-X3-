package com.kaiyi.oemlauncher

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.kaiyi.oemlauncher.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: LauncherPrefs
    private lateinit var appResolver: AppResolver
    private lateinit var mediaControlHelper: MediaControlHelper
    private lateinit var vehicleImageStorage: VehicleImageStorage

    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private var isVehicleProfile = false
    private var isAnimatingVehicle = false
    private var pendingVehicleSide = VehicleViewSide.FRONT
    private var frontBitmapCache: Bitmap? = null
    private var profileBitmapCache: Bitmap? = null
    private var cachedInstalledApps: List<InstalledApp> = emptyList()

    private val assignSlotLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            refreshSlotLabelsAsync()
        }
    }

    // Selector nativo Android 13 (Photo Picker)
    private val pickVisualMediaLauncher = registerForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            savePickedVehicleImage(uri)
        }
    }

    // Respaldo universal ACTION_GET_CONTENT para ROMs automotrices sin Photo Picker
    private val getContentFallbackLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            savePickedVehicleImage(uri)
        }
    }

    private val statusRefreshRunnable = object : Runnable {
        override fun run() {
            updateSpanishDate()
            updateMediaStateUi()
            updateConnectivityStatus()
            mainHandler.postDelayed(this, STATUS_POLL_INTERVAL_MS)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        enableFullscreenImmersive()

        prefs = LauncherPrefs(this)
        appResolver = AppResolver(this, prefs)
        mediaControlHelper = MediaControlHelper(this)
        vehicleImageStorage = VehicleImageStorage(this)

        // Bloquear botón Atrás en el Launcher HOME para no salir al vacío
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // En el launcher principal, Atrás mantiene al usuario en la pantalla de inicio
            }
        })

        setupVehicleShowcase()
        setupLeftQuickButtons()
        setupMediaPlayerCard()
        setupQuickAccessCard()
        setupBottomDock()
        updateSpanishDate()
        refreshSlotLabelsAsync()

        if (!hasShownBootSplash) {
            hasShownBootSplash = true
            launchSplashScreen(immediate = true)
        }
    }

    override fun onResume() {
        super.onResume()
        enableFullscreenImmersive()
        updateSpanishDate()
        updateMediaStateUi()
        updateConnectivityStatus()
        refreshSlotLabelsAsync()
        mainHandler.removeCallbacks(statusRefreshRunnable)
        mainHandler.postDelayed(statusRefreshRunnable, STATUS_POLL_INTERVAL_MS)
    }

    override fun onPause() {
        super.onPause()
        mainHandler.removeCallbacks(statusRefreshRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
        appResolver.clearIconCache()
        frontBitmapCache?.recycle()
        profileBitmapCache?.recycle()
        frontBitmapCache = null
        profileBitmapCache = null
    }

    private fun setupVehicleShowcase() {
        isVehicleProfile = prefs.isVehicleProfileView()
        applyCurrentVehicleImage()
        loadCustomVehicleBitmapsAsync()

        // Toque simple: alternar con animación fade entre foto frontal y perfil
        binding.ivVehicle.setOnClickListener {
            if (isAnimatingVehicle) return@setOnClickListener
            isAnimatingVehicle = true
            isVehicleProfile = !isVehicleProfile
            prefs.setVehicleProfileView(isVehicleProfile)

            binding.ivVehicle.animate()
                .alpha(0f)
                .setDuration(150L)
                .withEndAction {
                    applyCurrentVehicleImage()
                    binding.ivVehicle.animate()
                        .alpha(1f)
                        .setDuration(180L)
                        .withEndAction {
                            isAnimatingVehicle = false
                        }
                        .start()
                }
                .start()
        }

        // Mantener presionado sobre el vehículo: abrir selector de galería / opciones
        binding.ivVehicle.setOnLongClickListener {
            showVehicleCustomizationDialog()
            true
        }

        // Botón pequeño de configuración en la esquina del vehículo
        binding.btnVehiclePhotoConfig.setOnClickListener {
            showVehicleCustomizationDialog()
        }
    }

    private fun loadCustomVehicleBitmapsAsync() {
        executor.execute {
            val front = vehicleImageStorage.loadCustomBitmap(VehicleViewSide.FRONT)
            val profile = vehicleImageStorage.loadCustomBitmap(VehicleViewSide.PROFILE)
            mainHandler.post {
                if (isFinishing || isDestroyed) {
                    front?.recycle()
                    profile?.recycle()
                    return@post
                }
                frontBitmapCache?.recycle()
                profileBitmapCache?.recycle()
                frontBitmapCache = front
                profileBitmapCache = profile
                applyCurrentVehicleImage()
            }
        }
    }

    private fun applyCurrentVehicleImage() {
        val customBitmap = if (isVehicleProfile) profileBitmapCache else frontBitmapCache
        if (customBitmap != null && !customBitmap.isRecycled) {
            binding.ivVehicle.setImageBitmap(customBitmap)
        } else {
            binding.ivVehicle.setImageResource(
                if (isVehicleProfile) R.drawable.auto_perfil else R.drawable.auto_frente
            )
        }
    }

    private fun showVehicleCustomizationDialog() {
        val options = arrayOf(
            getString(R.string.vehicle_opt_pick_front),
            getString(R.string.vehicle_opt_pick_profile),
            getString(R.string.vehicle_opt_pick_brand_logo),
            getString(R.string.vehicle_opt_preview_splash),
            getString(R.string.vehicle_opt_settings),
            getString(R.string.vehicle_opt_restore)
        )

        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.vehicle_menu_title)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> launchGalleryPicker(VehicleViewSide.FRONT)
                    1 -> launchGalleryPicker(VehicleViewSide.PROFILE)
                    2 -> launchGalleryPicker(VehicleViewSide.BRAND_LOGO)
                    3 -> launchSplashScreen(immediate = false)
                    4 -> launchSlotWithFeedback(LauncherSlot.VEHICLE_SETTINGS)
                    5 -> restoreDefaultVehicleImages()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun launchSplashScreen(immediate: Boolean) {
        startActivity(Intent(this, SplashActivity::class.java))
        if (immediate) {
            @Suppress("DEPRECATION")
            overridePendingTransition(0, 0)
        }
    }

    private fun launchGalleryPicker(side: VehicleViewSide) {
        pendingVehicleSide = side

        if (ActivityResultContracts.PickVisualMedia.isPhotoPickerAvailable(this)) {
            val launchedPicker = runCatching {
                pickVisualMediaLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                )
            }.isSuccess
            if (launchedPicker) return
        }

        val launchedFallback = runCatching {
            getContentFallbackLauncher.launch("image/*")
        }.isSuccess

        if (!launchedFallback) {
            Toast.makeText(this, R.string.msg_no_gallery_app, Toast.LENGTH_SHORT).show()
        }
    }

    private fun savePickedVehicleImage(uri: Uri) {
        val targetSide = pendingVehicleSide
        executor.execute {
            val saved = vehicleImageStorage.saveImageFromUri(targetSide, uri)
            val updatedBitmap = if (saved) {
                vehicleImageStorage.loadCustomBitmap(targetSide)
            } else {
                null
            }

            mainHandler.post {
                if (isFinishing || isDestroyed) {
                    updatedBitmap?.recycle()
                    return@post
                }

                if (saved && updatedBitmap != null) {
                    prefs.setCustomVehiclePhotoSaved(targetSide, true)
                    if (targetSide == VehicleViewSide.BRAND_LOGO) {
                        updatedBitmap.recycle()
                        Toast.makeText(
                            this,
                            getString(R.string.msg_vehicle_photo_saved, targetSide.displayLabel),
                            Toast.LENGTH_SHORT
                        ).show()
                        launchSplashScreen(immediate = false)
                    } else {
                        if (targetSide == VehicleViewSide.FRONT) {
                            frontBitmapCache?.recycle()
                            frontBitmapCache = updatedBitmap
                            isVehicleProfile = false
                        } else {
                            profileBitmapCache?.recycle()
                            profileBitmapCache = updatedBitmap
                            isVehicleProfile = true
                        }
                        prefs.setVehicleProfileView(isVehicleProfile)
                        applyCurrentVehicleImage()
                        Toast.makeText(
                            this,
                            getString(R.string.msg_vehicle_photo_saved, targetSide.displayLabel),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    updatedBitmap?.recycle()
                    Toast.makeText(
                        this,
                        R.string.msg_vehicle_photo_error,
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    private fun restoreDefaultVehicleImages() {
        vehicleImageStorage.clearCustomImages()
        prefs.setCustomVehiclePhotoSaved(VehicleViewSide.FRONT, false)
        prefs.setCustomVehiclePhotoSaved(VehicleViewSide.PROFILE, false)
        prefs.setCustomVehiclePhotoSaved(VehicleViewSide.BRAND_LOGO, false)
        frontBitmapCache?.recycle()
        profileBitmapCache?.recycle()
        frontBitmapCache = null
        profileBitmapCache = null
        applyCurrentVehicleImage()
        Toast.makeText(this, R.string.msg_vehicle_photos_restored, Toast.LENGTH_SHORT).show()
    }

    private fun setupLeftQuickButtons() {
        bindConfigurableSlot(binding.btnQuickRadio, LauncherSlot.RADIO)
        bindConfigurableSlot(binding.btnQuickMusic, LauncherSlot.MUSIC)
        bindConfigurableSlot(binding.btnQuickPhone, LauncherSlot.PHONE)
        bindConfigurableSlot(binding.btnQuickZlink, LauncherSlot.ZLINK)
    }

    private fun setupMediaPlayerCard() {
        binding.btnMediaPrev.setOnClickListener {
            mediaControlHelper.sendPrevious()
            pulseView(it)
            mainHandler.postDelayed({ updateMediaStateUi() }, 200L)
        }

        binding.btnMediaPlayPause.setOnClickListener {
            mediaControlHelper.sendPlayPause()
            pulseView(it)
            mainHandler.postDelayed({ updateMediaStateUi() }, 200L)
        }

        binding.btnMediaNext.setOnClickListener {
            mediaControlHelper.sendNext()
            pulseView(it)
            mainHandler.postDelayed({ updateMediaStateUi() }, 200L)
        }
    }

    private fun setupQuickAccessCard() {
        bindConfigurableSlot(binding.tileQuickMaps, LauncherSlot.MAPS)
        bindConfigurableSlot(binding.tileQuickObd, LauncherSlot.OBD2)
        bindConfigurableSlot(binding.tileQuickEqualizer, LauncherSlot.EQUALIZER)
    }

    private fun setupBottomDock() {
        binding.btnDockHome.setOnClickListener {
            pulseView(it)
            updateMediaStateUi()
            updateConnectivityStatus()
        }

        bindConfigurableSlot(binding.btnDockNav, LauncherSlot.MAPS)

        binding.btnDockApps.setOnClickListener {
            startActivity(Intent(this, AppsDrawerActivity::class.java))
        }

        bindConfigurableSlot(binding.btnDockDsp, LauncherSlot.EQUALIZER)
        bindConfigurableSlot(binding.btnDockSettings, LauncherSlot.SYSTEM_SETTINGS)
    }

    private fun bindConfigurableSlot(view: View, slot: LauncherSlot) {
        view.setOnClickListener {
            launchSlotWithFeedback(slot)
        }
        view.setOnLongClickListener {
            openAppPickerForSlot(slot)
            true
        }
    }

    private fun launchSlotWithFeedback(slot: LauncherSlot) {
        val launched = appResolver.launchSlot(slot)
        if (!launched) {
            Toast.makeText(
                this,
                getString(R.string.msg_app_not_found, slot.defaultTitle),
                Toast.LENGTH_SHORT
            ).show()
            openAppPickerForSlot(slot)
        }
    }

    private fun openAppPickerForSlot(slot: LauncherSlot) {
        val pickerIntent = Intent(this, AppsDrawerActivity::class.java).apply {
            putExtra(AppsDrawerActivity.EXTRA_ASSIGN_SLOT_KEY, slot.prefKey)
        }
        assignSlotLauncher.launch(pickerIntent)
    }

    private fun refreshSlotLabelsAsync() {
        executor.execute {
            val apps = appResolver.getLaunchableApps(includeIcons = false)
            val resolvedMap = mapOf(
                LauncherSlot.RADIO to appResolver.resolvePackageForSlot(LauncherSlot.RADIO, apps),
                LauncherSlot.MUSIC to appResolver.resolvePackageForSlot(LauncherSlot.MUSIC, apps),
                LauncherSlot.PHONE to appResolver.resolvePackageForSlot(LauncherSlot.PHONE, apps),
                LauncherSlot.ZLINK to appResolver.resolvePackageForSlot(LauncherSlot.ZLINK, apps),
                LauncherSlot.MAPS to appResolver.resolvePackageForSlot(LauncherSlot.MAPS, apps),
                LauncherSlot.OBD2 to appResolver.resolvePackageForSlot(LauncherSlot.OBD2, apps),
                LauncherSlot.EQUALIZER to appResolver.resolvePackageForSlot(LauncherSlot.EQUALIZER, apps)
            )

            mainHandler.post {
                if (isFinishing || isDestroyed) return@post
                cachedInstalledApps = apps

                binding.tvQuickRadio.text =
                    resolvedMap[LauncherSlot.RADIO]?.label ?: getString(R.string.label_radio)
                binding.tvQuickMusic.text =
                    resolvedMap[LauncherSlot.MUSIC]?.label ?: getString(R.string.label_music)
                binding.tvQuickPhone.text =
                    resolvedMap[LauncherSlot.PHONE]?.label ?: getString(R.string.label_phone)
                binding.tvQuickZlink.text =
                    resolvedMap[LauncherSlot.ZLINK]?.label ?: getString(R.string.label_zlink)

                binding.tvTileMaps.text =
                    resolvedMap[LauncherSlot.MAPS]?.label ?: getString(R.string.label_maps)
                binding.tvTileObd.text =
                    resolvedMap[LauncherSlot.OBD2]?.label ?: getString(R.string.label_obd2)
                binding.tvTileEqualizer.text =
                    resolvedMap[LauncherSlot.EQUALIZER]?.label ?: getString(R.string.label_equalizer)
            }
        }
    }

    private fun updateSpanishDate() {
        val spanishLocale = Locale("es", "ES")
        val formatter = SimpleDateFormat("EEEE, d 'de' MMMM", spanishLocale)
        val rawDate = formatter.format(Date())
        binding.textDateSpanish.text = rawDate.replaceFirstChar {
            if (it.isLowerCase()) it.titlecase(spanishLocale) else it.toString()
        }
    }

    private fun updateMediaStateUi() {
        val isActive = mediaControlHelper.isMusicActive()
        binding.btnMediaPlayPause.setImageResource(
            if (isActive) R.drawable.ic_pause else R.drawable.ic_play
        )
        binding.tvMediaStateBadge.text = getString(
            if (isActive) R.string.media_status_active else R.string.media_status_idle
        )
        binding.tvMediaStateBadge.setTextColor(
            ContextCompat.getColor(
                this,
                if (isActive) R.color.oem_turquoise else R.color.text_secondary
            )
        )
    }

    private fun updateConnectivityStatus() {
        val wifiConnected = isWifiConnected()
        val btEnabled = isBluetoothEnabled()
        val gpsEnabled = isGpsEnabled()

        applyStatusTint(binding.ivStatusWifi, binding.tvStatusWifi, wifiConnected)
        applyStatusTint(binding.ivStatusBluetooth, binding.tvStatusBluetooth, btEnabled)
        applyStatusTint(binding.ivStatusGps, binding.tvStatusGps, gpsEnabled)
    }

    private fun applyStatusTint(icon: ImageView, label: TextView, active: Boolean) {
        val tintColor = ContextCompat.getColor(
            this,
            if (active) R.color.status_connected else R.color.status_disconnected
        )
        val textColor = ContextCompat.getColor(
            this,
            if (active) R.color.text_accent else R.color.text_secondary
        )
        icon.setColorFilter(tintColor)
        label.setTextColor(textColor)
    }

    private fun isWifiConnected(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    }

    private fun isBluetoothEnabled(): Boolean {
        val btManager = getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val adapter = btManager?.adapter ?: return false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val hasPermission = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.BLUETOOTH_CONNECT
            ) == PackageManager.PERMISSION_GRANTED
            if (!hasPermission) return false
        }
        return runCatching { adapter.isEnabled }.getOrDefault(false)
    }

    private fun isGpsEnabled(): Boolean {
        val lm = getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return false
        return runCatching {
            lm.isProviderEnabled(LocationManager.GPS_PROVIDER)
        }.getOrDefault(false)
    }

    private fun pulseView(view: View) {
        view.animate()
            .scaleX(0.92f)
            .scaleY(0.92f)
            .setDuration(80L)
            .withEndAction {
                view.animate().scaleX(1f).scaleY(1f).setDuration(120L).start()
            }
            .start()
    }

    private fun enableFullscreenImmersive() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, binding.root).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    companion object {
        private const val STATUS_POLL_INTERVAL_MS = 4000L
        private var hasShownBootSplash = false
    }
}
