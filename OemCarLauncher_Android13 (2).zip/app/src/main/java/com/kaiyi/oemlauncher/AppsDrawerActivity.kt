package com.kaiyi.oemlauncher

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.kaiyi.oemlauncher.databinding.ActivityAppsDrawerBinding
import java.util.concurrent.Executors

class AppsDrawerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAppsDrawerBinding
    private lateinit var prefs: LauncherPrefs
    private lateinit var appResolver: AppResolver
    private lateinit var adapter: AppsDrawerAdapter

    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private var allApps: List<InstalledApp> = emptyList()
    private var assignSlot: LauncherSlot? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppsDrawerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        enableFullscreenImmersive()

        prefs = LauncherPrefs(this)
        appResolver = AppResolver(this, prefs)

        assignSlot = LauncherSlot.fromPrefKey(intent.getStringExtra(EXTRA_ASSIGN_SLOT_KEY))
        configureHeaderForMode()

        adapter = AppsDrawerAdapter { selectedApp ->
            handleAppSelection(selectedApp)
        }

        // Cuadrícula horizontal de 3 filas optimizada para pantalla panorámica de 9 pulgadas
        binding.rvAppsGrid.layoutManager =
            GridLayoutManager(this, 3, RecyclerView.HORIZONTAL, false)
        binding.rvAppsGrid.setHasFixedSize(true)
        binding.rvAppsGrid.adapter = adapter

        binding.btnDrawerBack.setOnClickListener {
            finish()
        }

        binding.etSearchApps.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterApps(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })

        loadInstalledAppsAsync()
    }

    override fun onResume() {
        super.onResume()
        enableFullscreenImmersive()
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
        appResolver.clearIconCache()
    }

    private fun configureHeaderForMode() {
        val slot = assignSlot
        if (slot != null) {
            binding.tvDrawerTitle.text = getString(R.string.drawer_pick_title, slot.defaultTitle)
        } else {
            binding.tvDrawerTitle.text = getString(R.string.drawer_title)
        }
    }

    private fun loadInstalledAppsAsync() {
        executor.execute {
            val loaded = appResolver.getLaunchableApps(includeIcons = true)
            mainHandler.post {
                if (isFinishing || isDestroyed) return@post
                allApps = loaded
                filterApps(binding.etSearchApps.text?.toString().orEmpty())
            }
        }
    }

    private fun filterApps(query: String) {
        val trimmed = query.trim().lowercase()
        val filtered = if (trimmed.isEmpty()) {
            allApps
        } else {
            allApps.filter {
                it.label.lowercase().contains(trimmed) ||
                    it.packageName.lowercase().contains(trimmed)
            }
        }

        adapter.submitList(filtered)
        binding.tvEmptyApps.visibility = if (filtered.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun handleAppSelection(app: InstalledApp) {
        val slot = assignSlot
        if (slot != null) {
            prefs.setAssignedPackage(slot, app.packageName)
            Toast.makeText(
                this,
                getString(R.string.msg_app_assigned, slot.defaultTitle, app.label),
                Toast.LENGTH_SHORT
            ).show()
            setResult(
                Activity.RESULT_OK,
                Intent().putExtra(EXTRA_ASSIGN_SLOT_KEY, slot.prefKey)
            )
            finish()
        } else {
            val launched = appResolver.launchPackage(app.packageName)
            if (launched) {
                finish()
            } else {
                Toast.makeText(
                    this,
                    getString(R.string.msg_app_not_found, app.label),
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun enableFullscreenImmersive() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, binding.root).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    companion object {
        const val EXTRA_ASSIGN_SLOT_KEY = "extra_assign_slot_key"
    }
}
