package com.kaiyi.oemlauncher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.drawable.Drawable
import android.os.Build
import android.provider.Settings
import android.util.LruCache

data class InstalledApp(
    val label: String,
    val packageName: String,
    val icon: Drawable? = null
)

class AppResolver(
    private val context: Context,
    private val prefs: LauncherPrefs
) {
    private val pm: PackageManager = context.packageManager

    // Caché ligera optimizada para radios Android 13 con 2 GB de RAM
    private val iconCache = LruCache<String, Drawable>(48)

    fun getLaunchableApps(includeIcons: Boolean = true): List<InstalledApp> {
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val resolveInfos: List<ResolveInfo> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(
                mainIntent,
                PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_ALL.toLong())
            )
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(mainIntent, 0)
        }

        val selfPackage = context.packageName
        val seenPackages = HashSet<String>()
        val result = ArrayList<InstalledApp>(resolveInfos.size)

        for (info in resolveInfos) {
            val pkg = info.activityInfo?.packageName ?: continue
            if (pkg == selfPackage || !seenPackages.add(pkg)) continue

            val label = info.loadLabel(pm)?.toString()?.trim().orEmpty()
                .ifEmpty { pkg }

            val icon = if (includeIcons) {
                iconCache.get(pkg) ?: runCatching { info.loadIcon(pm) }.getOrNull()?.also {
                    iconCache.put(pkg, it)
                }
            } else {
                null
            }

            result.add(InstalledApp(label = label, packageName = pkg, icon = icon))
        }

        return result.sortedBy { it.label.lowercase() }
    }

    /**
     * Resuelve el paquete asignado por el usuario en SharedPreferences o busca
     * automáticamente la app de fábrica mediante palabras clave en PackageManager.
     */
    fun resolvePackageForSlot(slot: LauncherSlot, cachedApps: List<InstalledApp>? = null): InstalledApp? {
        val apps = cachedApps ?: getLaunchableApps(includeIcons = false)

        // 1. Prioridad: asignación manual guardada en SharedPreferences
        val savedPkg = prefs.getAssignedPackage(slot)
        if (!savedPkg.isNullOrBlank()) {
            val matchedSaved = apps.firstOrNull { it.packageName == savedPkg }
            if (matchedSaved != null) return matchedSaved
        }

        // 2. Búsqueda inteligente por palabras clave (en orden de prioridad)
        for (keyword in slot.keywords) {
            val lowerKey = keyword.lowercase()
            val matchByPkg = apps.firstOrNull {
                it.packageName.lowercase().contains(lowerKey)
            }
            if (matchByPkg != null) return matchByPkg

            val matchByLabel = apps.firstOrNull {
                it.label.lowercase().contains(lowerKey)
            }
            if (matchByLabel != null) return matchByLabel
        }

        return null
    }

    fun launchSlot(slot: LauncherSlot): Boolean {
        val resolved = resolvePackageForSlot(slot)
        if (resolved != null && launchPackage(resolved.packageName)) {
            return true
        }

        // Respaldo seguro para Ajustes del Sistema o Ajustes del Vehículo
        if (slot == LauncherSlot.SYSTEM_SETTINGS || slot == LauncherSlot.VEHICLE_SETTINGS) {
            return launchSystemSettings()
        }
        return false
    }

    fun launchPackage(packageName: String): Boolean {
        val launchIntent = pm.getLaunchIntentForPackage(packageName)?.apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        } ?: return false

        return runCatching {
            context.startActivity(launchIntent)
            true
        }.getOrDefault(false)
    }

    fun launchSystemSettings(): Boolean {
        val settingsIntent = Intent(Settings.ACTION_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return runCatching {
            context.startActivity(settingsIntent)
            true
        }.getOrDefault(false)
    }

    fun clearIconCache() {
        iconCache.evictAll()
    }
}
