package com.kaiyi.oemlauncher

import android.content.Context
import android.content.SharedPreferences

class LauncherPrefs(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getAssignedPackage(slot: LauncherSlot): String? {
        return prefs.getString(slot.prefKey, null)
    }

    fun setAssignedPackage(slot: LauncherSlot, packageName: String) {
        prefs.edit().putString(slot.prefKey, packageName).apply()
    }

    fun clearAssignedPackage(slot: LauncherSlot) {
        prefs.edit().remove(slot.prefKey).apply()
    }

    fun isVehicleProfileView(): Boolean {
        return prefs.getBoolean(KEY_VEHICLE_PROFILE, false)
    }

    fun setVehicleProfileView(isProfile: Boolean) {
        prefs.edit().putBoolean(KEY_VEHICLE_PROFILE, isProfile).apply()
    }

    companion object {
        private const val PREFS_NAME = "oem_car_launcher_prefs"
        private const val KEY_VEHICLE_PROFILE = "vehicle_view_profile"
    }
}
