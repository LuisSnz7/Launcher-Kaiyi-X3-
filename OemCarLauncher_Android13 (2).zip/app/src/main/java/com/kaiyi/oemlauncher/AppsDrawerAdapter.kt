package com.kaiyi.oemlauncher

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.kaiyi.oemlauncher.databinding.ItemAppDrawerBinding

class AppsDrawerAdapter(
    private val onAppClick: (InstalledApp) -> Unit
) : RecyclerView.Adapter<AppsDrawerAdapter.AppViewHolder>() {

    private val items = ArrayList<InstalledApp>()

    fun submitList(newItems: List<InstalledApp>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder {
        val binding = ItemAppDrawerBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return AppViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class AppViewHolder(
        private val binding: ItemAppDrawerBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(app: InstalledApp) {
            binding.tvAppName.text = app.label
            if (app.icon != null) {
                binding.ivAppIcon.setImageDrawable(app.icon)
            } else {
                binding.ivAppIcon.setImageResource(R.drawable.ic_apps_grid)
            }
            binding.root.setOnClickListener {
                onAppClick(app)
            }
        }
    }
}
