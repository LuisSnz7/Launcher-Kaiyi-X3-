package com.kaiyi.oemlauncher

enum class LauncherSlot(
    val prefKey: String,
    val defaultTitle: String,
    val keywords: List<String>
) {
    RADIO(
        prefKey = "slot_radio",
        defaultTitle = "Radio",
        keywords = listOf("radio", "fm", "dab", "tuner", "carradio")
    ),
    MUSIC(
        prefKey = "slot_music",
        defaultTitle = "Música",
        keywords = listOf("ymusic", "music", "spotify", "poweramp", "aimp", "audio", "player")
    ),
    PHONE(
        prefKey = "slot_phone",
        defaultTitle = "Teléfono",
        keywords = listOf("phone", "dialer", "bt", "bluetooth", "btphone", "call")
    ),
    ZLINK(
        prefKey = "slot_zlink",
        defaultTitle = "ZLINK5",
        keywords = listOf("zlink", "tlink", "carlink", "carplay", "androidauto", "speedplay")
    ),
    MAPS(
        prefKey = "slot_maps",
        defaultTitle = "Maps",
        keywords = listOf("maps", "waze", "navi", "igo", "osmand", "gmap")
    ),
    OBD2(
        prefKey = "slot_obd2",
        defaultTitle = "OBD2 / Torque",
        keywords = listOf("torque", "obd", "carscanner", "elm327", "diagnostic")
    ),
    EQUALIZER(
        prefKey = "slot_equalizer",
        defaultTitle = "Ecualizador",
        keywords = listOf("equalizer", "dsp", "eq", "sound", "viper", "audiofx", "amplifier")
    ),
    VEHICLE_SETTINGS(
        prefKey = "slot_vehicle_settings",
        defaultTitle = "Ajustes del Vehículo",
        keywords = listOf("carsetting", "carinfo", "vehicle", "canbus", "car", "settings")
    ),
    SYSTEM_SETTINGS(
        prefKey = "slot_system_settings",
        defaultTitle = "Ajustes del Sistema",
        keywords = listOf("settings", "com.android.settings")
    );

    companion object {
        fun fromPrefKey(key: String?): LauncherSlot? {
            return values().firstOrNull { it.prefKey == key }
        }
    }
}
